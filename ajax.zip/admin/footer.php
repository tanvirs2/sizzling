<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; <?php echo date('Y'); ?> <a href="http://devcastle.net" target="_blank">Nazrul Kabir</a>.</strong> All rights
    reserved.
</footer>