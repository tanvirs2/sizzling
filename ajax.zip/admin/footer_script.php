<script src="<?php echo baseUrl('admin/resources/js/jquery-3.2.1.min.js') ?>"></script>
<script src="<?php echo baseUrl('admin/resources/js/bootstrap.min.js') ?>"></script>
<script src="<?php echo baseUrl('admin/resources/js/adminlte.min.js') ?>"></script>
