<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
    <table border="0" width="100%" cellpadding="0" cellspacing="0">
        <tbody><tr><td height="30"></td></tr>
            <tr bgcolor="#4c4e4e">
                <td width="100%" align="center" valign="top" bgcolor="#4c4e4e">
                    <table border="0" width="600" cellpadding="0" cellspacing="0" align="center" class="container">
                        <tbody>
                            <tr bgcolor="272727"><td height="5"></td></tr>
                            <tr bgcolor="272727">
                                <td align="center">
                                    <table border="0" width="560" align="center" cellpadding="0" cellspacing="0" class="container-middle">
                                        <tbody>
                                            <tr bgcolor="272727">
                                                <td height="10"></td></tr><tr>
                                                <td>
                                                    <table border="0" align="left" cellpadding="0" cellspacing="0" class="top-header-left">
                                                        <tbody><tr>
                                                                <td align="center">
                                                                    <table border="0" cellpadding="0" cellspacing="0" class="date">
                                                                        <tbody><tr>
                                                                                <td> <i class="fa fa-calendar" aria-hidden="true" style="color: white;"></i>
                                                                                </td>
                                                                                <td>&nbsp;&nbsp;</td>
                                                                                <td mc:edit="date" style="color: #fefefe; font-size: 12px; font-weight: normal; font-family: Helvetica, Arial, sans-serif;">
                                                                        <singleline>
                                                                            <?php echo date('l jS \of F Y'); ?>
                                                                        </singleline>
                                                                </td>
                                                            </tr>
                                                        </tbody></table>
                                                </td>
                                            </tr>
                                        </tbody></table>

                                    <table border="0" align="left" cellpadding="0" cellspacing="0" class="top-header-right">
                                        <tbody><tr><td width="30" height="20"></td></tr>
                                        </tbody></table>

                                    <table border="0" align="right" cellpadding="0" cellspacing="0" class="top-header-right">
                                        <tbody><tr>
                                                <td align="center">
                                                    <table border="0" cellpadding="0" cellspacing="0" align="center" class="tel">
                                                        <tbody><tr>
                                                                <td>
                                                                    <i class="fa fa-phone-square" aria-hidden="true" style="color: white;"></i>
                                                                </td>
                                                                <td>&nbsp;&nbsp;</td>
                                                                <td mc:edit="tel" style="color: #fefefe; font-size: 12px; font-weight: normal; font-family: Helvetica, Arial, sans-serif;">
                                                        <singleline>
                                                            Call : +(44) XXXXXXX
                                                        </singleline>
                                                </td>
                                            </tr>
                                        </tbody></table>
                                </td>
                            </tr>					                    	
                        </tbody></table>
                </td>
            </tr>
        </tbody></table>
</td>
</tr>
<tr bgcolor="272727">
    <td height="10"></td></tr>
</tbody>
</table>
<table width="600" border="0" cellpadding="0" cellspacing="0" align="center" class="container" bgcolor="ececec">
    <tbody><tr bgcolor="ececec"><td height="40"></td></tr>
        <tr >
            <td align="center">
                <table class="logo" cellspacing="0" cellpadding="0" border="0" align="center">
                    <tbody>
                        <tr>
<!--                            <td align="center">-->
<!--                                <a href="http://znzfashion.com" target="_blank" style="display: block;text-align: center;"><img editable="true" mc:edit="logo" style="display: block;" src="http://znzfashion.com/images/znz_logo_horizontal.png" alt="Zaber & Zubair Fabrics Ltd." width="155"></a>-->
<!--                            </td>-->
                        </tr>
                    </tbody>
                </table>           
            </td>
        </tr>