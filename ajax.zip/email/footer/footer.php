<tr><td height="35"></td></tr>
<tr>
    <td>
        <table border="0" width="560" align="center" cellpadding="0" cellspacing="0" class="container-middle">
            <tbody>

            </tbody></table>
    </td>
</tr>                                                    
</td>
</tr>

<tr><td height="30"></td></tr>
</tbody>
</table>
<table border="0" width="600" cellpadding="0" cellspacing="0" class="container">
    <tbody><tr bgcolor="272727"><td height="14"></td></tr>
        <tr bgcolor="272727">
            <td mc:edit="copy3" align="center" style="color: #cecece; font-size: 10px; font-weight: normal; font-family: Helvetica, Arial, sans-serif;">
    <multiline>
        Please do not reply to this email. Emails sent to this address will not be answered. 
    </multiline> 
    <br>
    <multiline>
        &copy; <?php echo date("Y"); ?>. All Rights Reserved.
    </multiline>
</td>
</tr>
<tr bgcolor="272727"><td height="14"></td></tr>                                                        
</tbody>
</table>
</td>
</tr>
<tr><td height="30"></td></tr>