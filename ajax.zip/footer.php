<footer>
    <div class="footer-area-top">
        <div class="container">
            <div class="row">
                <div class="col-sm-4 col-xs-12">
                    <div class="single-widget">
                        <div id="redchili_about_widget-3" class="widget widget_redchili_about_widget">
                            <h3 class="widgettitle widget-title-bar">About SIZZLING</h3>
                            <div class="textwidget">
                                We sell peri-peri chicken, hot wings, Taste burgers, and Fish and chips. Our Recipe is unique and the taste is different than others.  come and try our yummy food.
                            </div>
                            <div class="footer-social-media-area">
                                <ul class="footer-social">
                                    <li><a href="https://www.facebook.com/sizzling2019/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="https://www.instagram.com/sizzlingperi71/" target="_blank"><i class="fa fa-instagram"></i></a></li>
                                    <li><a href="#" target="_blank"><i class="fa fa-linkedin"></i></a></li>
<!--                                    <li><a style="background-color:#e7272d;" href="https://www.tripadvisor.com/Restaurant_Review-g1010168-d5440212-Reviews-Aangon_Indian_Restaurant-Carterton_Oxfordshire_England.html" target="_blank"><img src="assets/img/tripadvisor-logotype.png" style="margin-left: auto;margin-right: auto;border-radius: 5px;border:none"></a></li>-->
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-xs-12">
                    <div class="single-widget">
                        <div id="text-4" class="widget widget_text">
                            <h3 class="widgettitle widget-title-bar">Contact</h3>
                            <div class="textwidget">
                                <ul class="list-unstyled text-left">
                                    <li><a>Sizzling</a></li>
                                    <li><strong>Tel:</strong> <a href="tel:+44 20 8590 4858">+44 20 8590 4858</a></li>
                                    <li><strong>Email:</strong> <a href="mailto:71sizzling@gmail.com">71sizzling@gmail.com</a></li>
                                    <li><a>71, Chadwell heath lane, Romford, United Kingdom</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-xs-12">
                    <div class="single-widget">
                        <div id="text-5" class="widget widget_text">
                            <h3 class="widgettitle widget-title-bar">Opening / Closing Time:</h3>
                            <div class="textwidget">
                                <p>Sunday - Thursday<br />
                                    11:00 - 22:00 </p>
                                <p> Friday - Saturday <br />
                                    11:00 - 23:00 </p>
                                <p>&nbsp;</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-area-bottom">
        <div class="container">
            <p>&copy; Sizzling <?php echo date('Y');?>. All Right Reserved. Designed and Developed by <a href="#" style="color:#fff">Technos</a></p>
        </div>
    </div>
</footer>